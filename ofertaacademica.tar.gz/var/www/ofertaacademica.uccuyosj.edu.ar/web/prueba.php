<?php
echo "hola";
?>